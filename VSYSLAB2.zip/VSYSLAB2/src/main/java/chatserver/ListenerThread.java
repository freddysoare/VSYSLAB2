package chatserver;

import java.io.PrintStream;

/**
 * Created by alfredmincinoiu on 01/11/2016.
 */
public class ListenerThread extends Thread{
    protected PrintStream os = null;
    protected String clientName = null;


}
